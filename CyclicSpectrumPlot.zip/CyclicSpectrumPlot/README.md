# CyclicSpectrumPlot
The MATLAB function, CycSpecFft, is used to get the cyclic spectrum of an input signal sequence.

The usage can be found by following MATLAB code:
```
help CycSpecFft
```

来自CSDN参考，直接FFT求频谱法，也可以频域平滑